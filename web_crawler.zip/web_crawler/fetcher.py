import requests
from bs4 import BeautifulSoup
import csv
import random
import time

# Default Headers (Fallback)
HEADERS = {
    "User-Agent": random.choice([
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36",
    ])
}

def fetch_page(url):
    """Fetches a web page and returns the HTML content."""
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        if response.status_code == 200:
            return response.text  # Return HTML content
        else:
            print(f"❌ Failed to fetch {url} - Status Code: {response.status_code}")
            return None
    except requests.exceptions.RequestException as e:
        print(f"⚠️ Error fetching {url}: {e}")
        return None

def save_to_csv(data, filename="scraped_data.csv"):
    """Save extracted data to a CSV file."""
    with open(filename, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["Title", "URL", "Content"])  # Headers
        writer.writerows(data)

def extract_links(html, base_url):
    """Extracts all links from a page and converts relative URLs to absolute."""
    soup = BeautifulSoup(html, "html.parser")
    links = set()

    title = soup.title.string if soup.title else "No Title"
    paragraphs = " ".join(p.text for p in soup.find_all("p"))  # Extract all paragraphs

    # Extract all links
    for a_tag in soup.find_all("a", href=True):
        link = a_tag["href"]
        if link.startswith("http"):  # Absolute link
            links.add(link)
        else:  # Relative link
            links.add(base_url + link)

    return title, base_url, paragraphs, list(links)  # Return links as well
