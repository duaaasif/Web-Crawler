from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

def fetch_dynamic_page(url):
    """Fetches a JavaScript-rendered page using Selenium."""
    options = Options()
    options.add_argument("--headless")  # Run in headless mode (no GUI)
    options.add_argument("--disable-gpu")  # Disable GPU for faster execution
    options.add_argument("--no-sandbox")  # Bypass OS security model
    options.add_argument("--disable-dev-shm-usage")  # Overcome limited resource problems

    # Setup Chrome WebDriver
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)
    
    try:
        driver.get(url)
        driver.implicitly_wait(5)  # Wait for JavaScript to load
        page_source = driver.page_source  # Get fully rendered HTML
    finally:
        driver.quit()  # Close the browser
    
    return page_source
