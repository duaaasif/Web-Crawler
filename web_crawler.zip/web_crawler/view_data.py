import sqlite3
import pandas as pd
import ast  # To properly format lists stored as strings

def view_data():
    """Fetches and displays stored crawled data in a clean table format."""
    
    conn = sqlite3.connect("crawler_data.db")
    
    # Fetch data into a Pandas DataFrame
    df = pd.read_sql_query("SELECT * FROM crawled_data", conn)

    # Convert stringified lists back to actual lists (if needed)
    if 'headings' in df.columns:
        df['headings'] = df['headings'].apply(lambda x: ', '.join(ast.literal_eval(x)) if isinstance(x, str) and x.startswith("[") else x)
    if 'links' in df.columns:
        df['links'] = df['links'].apply(lambda x: ', '.join(ast.literal_eval(x)) if isinstance(x, str) and x.startswith("[") else x)
    if 'images' in df.columns:
        df['images'] = df['images'].apply(lambda x: ', '.join(ast.literal_eval(x)) if isinstance(x, str) and x.startswith("[") else x)

    # Set Pandas display options for better formatting
    pd.set_option('display.max_colwidth', None)  # Show full content in columns
    pd.set_option('display.expand_frame_repr', False)  # Prevent newlines within DataFrame
    pd.set_option('display.width', None)  # Auto-detect the display width
    pd.set_option('display.max_rows', None)  # Show all rows
    df = df[['url', 'headings', 'images', 'links']]  # Select specific columns
    # Print the DataFrame in a clean table format
    print(df.to_string(index=False))  # Removes the index column for cleaner output

    conn.close()

view_data()