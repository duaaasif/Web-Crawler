import requests
from bs4 import BeautifulSoup
import random
import time
import csv
from fetcher import fetch_page

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36",
]

def fetch_page_selenium(url):
    headers = {"User-Agent": random.choice(USER_AGENTS)}
    response = requests.get(url, headers=headers, timeout=5)
    time.sleep(random.uniform(1, 3))  # Delay to prevent bans
    return response.text if response.status_code == 200 else None

def extract_links(html, base_url):
    soup = BeautifulSoup(html, "html.parser")
    links = set()

    for a_tag in soup.find_all("a", href=True):
        link = a_tag["href"]
        if link.startswith("http"):
            links.add(link)
        else:
            links.add(base_url + link)
    
    return links

def extract_content(html, url):
    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.string if soup.title else "No Title"
    paragraphs = " ".join(p.text for p in soup.find_all("p"))
    return [title, url, paragraphs]

def save_to_csv(data, filename="scraped_data.csv"):
    with open(filename, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["Title", "URL", "Content"])
        writer.writerows(data)

def crawl(start_url, max_pages=5):
    visited = set()
    to_visit = {start_url}
    data = []

    while to_visit and len(visited) < max_pages:
        url = to_visit.pop()
        if url in visited:
            continue

        print(f"Crawling: {url}")
        html = fetch_page(url)
        if html:
            data.append(extract_content(html, url))
            to_visit.update(extract_links(html, start_url))

        visited.add(url)

    save_to_csv(data)
    print("Crawling complete! Data saved to scraped_data.csv")

# Run crawler
start_url = "https://toscrape.com/"  # Replace with a real website
crawl(start_url, max_pages=10)
