# WEB CRAWLER project by Aliza Fatima ( 23k-2054 ) and Dua Asif ( 23k- 2059 )
from fetcher import fetch_page
from extractor import extract_data
from crawler import crawl
from selenium_fetcher import fetch_dynamic_page
from robots_checker import can_crawl
from urllib.parse import urlparse


if __name__ == "__main__":
    url = input(f"Enter any url: ") #url to scrap

    parsed = urlparse(url)
    base_url = f"{parsed.scheme}://{parsed.netloc}"
    path = parsed.path if parsed.path else "/"

    if not can_crawl(base_url, path):
        exit()  # Stop the program
   
 # 🔍 Sample demo websites to test this crawler:
# These sites are known to allow scraping or are built for educational/testing purposes.

# https://books.toscrape.com/        
# https://quotes.toscrape.com/        
# https://webscraper.io/test-sites     
# https://httpbin.org/               
# https://example.com/                
# https://news.ycombinator.com/       



    html_content = fetch_dynamic_page(url)
    #set depth = 0 for single page crawling , not following any links. and increase depth to follow the links on website
    crawl(url, depth=0 , use_selenium=True)  # Crawl up to n levels deep

    if html_content:
        print("✅ Web page fetched successfully!\n")
        print("✅ JavaScript-rendered page fetched successfully!\n")
    
        print("\n🔹 Preview of HTML Content (First 500 chars):\n")
        print(html_content[:500])  # Print first 500 characters
        
        data = extract_data(html_content)

        print("\n📌 Extracted Data Summary:")
        print(f"🔹 Headings - H1: {len(data['h1'])}, H2: {len(data['h2'])}, H3: {len(data['h3'])}")
        print(f"📝 Paragraphs Extracted: {len(data['paragraphs'])}")
        print(f"🖼 Images Found - PNG: {len(data['png_images'])}, JPG: {len(data['jpg_images'])}, Other: {len(data['other_images'])}")
        print(f"🔗 Links Extracted: {len(data['links'])}")
        print("=" * 100)  # Separator for readability
