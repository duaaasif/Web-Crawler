from bs4 import BeautifulSoup
import re

def extract_data(html_content):
    """Extracts headings, paragraphs, images, and links from a web page."""
    soup = BeautifulSoup(html_content, "html.parser")

    # Extract headings
    h1 = [tag.get_text(strip=True) for tag in soup.find_all("h1")]
    h2 = [tag.get_text(strip=True) for tag in soup.find_all("h2")]
    h3 = [tag.get_text(strip=True) for tag in soup.find_all("h3")]
    # Extract paragraphs
    paragraphs = [p.get_text(strip=True) for p in soup.find_all("p")]

     # Extract images and categorize by type
    png_images = [img["src"] for img in soup.find_all("img", src=re.compile(r".*\.png"))]
    jpg_images = [img["src"] for img in soup.find_all("img", src=re.compile(r".*\.jpg|.*\.jpeg"))]
    other_images = [img["src"] for img in soup.find_all("img") if img.get("src") and img.get("src") not in png_images + jpg_images]
     # Extract links and filter out ads/tracking links
    unwanted_keywords = ["ads", "tracker", "analytics", "facebook", "google"]
    links = [a["href"] for a in soup.find_all("a", href=True) if not any(k in a["href"] for k in unwanted_keywords)]
    
    return {
        "h1": h1,
        "h2": h2,
        "h3": h3,
        "paragraphs": paragraphs,
        "png_images": png_images,
        "jpg_images": jpg_images,
        "other_images": other_images,
        "links": links
    }
