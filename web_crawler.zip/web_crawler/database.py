import sqlite3

def insert_data(url, h1, h2, h3, paragraphs, png_images, jpg_images, other_images, links):
    """Inserts crawled data into the database if the URL is not already present."""
    conn = sqlite3.connect("crawler_data.db") #crawler_data.db
    cursor = conn.cursor()

    # Check if the URL already exists
    cursor.execute("SELECT COUNT(*) FROM crawled_data WHERE url = ?", (url,))
    result = cursor.fetchone()

    if result[0] > 0:
        print(f"⚠️ Skipping duplicate: {url} (Already in database)")
    else:
        print(f"📝 Preparing to insert: {url}")
        #print(f"SQL Query: INSERT INTO crawled_data (url, h1, h2, h3, paragraphs, png_images, jpg_images, other_images, links) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")
        #rint(f"H1: {h1}, H2: {h2}, H3: {h3}")
        #print(f"Paragraphs: {paragraphs[:5]}...")  # Print first 5 paragraphs
        #print(f"PNG: {png_images}, JPG: {jpg_images}, Other: {other_images}")
        #print(f"Links: {links[:5]}...")  # Print first 5 links

        try:
            cursor.execute(
                "INSERT INTO crawled_data (url, h1, h2, h3, paragraphs, png_images, jpg_images, other_images, links) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (url, str(h1), str(h2), str(h3), str(paragraphs), str(png_images), str(jpg_images), str(other_images), str(links))
            )
            

            conn.commit()
            print(f"✅ Data stored for: {url}")
        except sqlite3.Error as e:
            print(f"❌ Database Insert Error: {e}")

    cursor.close()
    conn.close()

def create_database():
    """Creates an SQLite database and a table if not exists."""
    conn = sqlite3.connect("crawler_data.db")
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS crawled_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT UNIQUE,
            h1 TEXT,
            h2 TEXT,
            h3 TEXT,
            paragraphs TEXT,
            png_images TEXT,
            jpg_images TEXT,
            other_images TEXT,
            links TEXT
        )
    ''')

    conn.commit()
    conn.close()

create_database()
print("✅ Database initialized successfully!")
