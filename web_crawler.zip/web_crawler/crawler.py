import time
from fetcher import fetch_page
from selenium_fetcher import fetch_dynamic_page
from extractor import extract_data
from robots_checker import can_crawl
from urllib.parse import urlparse
from database import insert_data

def crawl(url, depth, visited=set(), use_selenium=False):
    """Recursively crawls links up to a given depth."""
    parsed_url = urlparse(url)
    base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"

    if depth < 0 or url in visited  or not can_crawl(base_url, parsed_url.path):
        return

    print(f"🔎 Crawling: {url}")
    visited.add(url)

    html_content = fetch_dynamic_page(url) if use_selenium else fetch_page(url)
    if not html_content:
        return

    data = extract_data(html_content)
     # Store data in database
    print(f"📝 Storing data for {url} in the database...")
    insert_data(url, data["h1"], data["h2"], data["h3"], data["paragraphs"],
                data["png_images"], data["jpg_images"], data["other_images"], data["links"])

    print(f"🔹 Crawled: {url}")
    print("=" * 80)  # Separator for readability


    # Crawl only internal links (same domain)
    for link in data["links"]:
        if link.startswith("http") and link not in visited:
            time.sleep(1)  # Delay to prevent overloading servers
            crawl(link, depth - 1, visited)
