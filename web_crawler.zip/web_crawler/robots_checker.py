import requests
from urllib.parse import urljoin

def can_crawl(base_url, path="/"):
    """Checks if crawling is allowed on a given URL based on robots.txt."""
    robots_url = urljoin(base_url, "/robots.txt")
    
    try:
        response = requests.get(robots_url, timeout=5)
        if response.status_code == 200:
            rules = response.text.lower()
            if f"disallow: {path}" in rules:
                print(f"🚫 Crawling blocked by robots.txt: {path}")
                return False
            print(f"✅ Crawling allowed: {path}")
            return True
    except requests.exceptions.RequestException:
        print("⚠️ Could not fetch robots.txt, assuming allowed.")
        return True

    return True
